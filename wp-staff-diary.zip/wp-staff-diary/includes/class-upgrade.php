<?php
/**
 * Handle plugin upgrades and database migrations
 *
 * @since      1.0.0
 * @package    WP_Staff_Diary
 */
class WP_Staff_Diary_Upgrade {

    /**
     * Check and run upgrades if needed
     */
    public static function check_upgrades() {
        $current_version = get_option('wp_staff_diary_version', '0.0.0');

        if (version_compare($current_version, WP_STAFF_DIARY_VERSION, '<')) {
            self::run_upgrades($current_version);
            update_option('wp_staff_diary_version', WP_STAFF_DIARY_VERSION);
        }
    }

    /**
     * Run necessary upgrades
     */
    private static function run_upgrades($from_version) {
        global $wpdb;

        // Add job_time column if it doesn't exist
        $table_diary = $wpdb->prefix . 'staff_diary_entries';
        $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $table_diary LIKE 'job_time'");

        if (empty($column_exists)) {
            $wpdb->query("ALTER TABLE $table_diary ADD COLUMN job_time time DEFAULT NULL AFTER job_date");
        }
    }
}
